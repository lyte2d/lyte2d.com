-- key input and last pressed keys

function lyte.tick()
    local keys = {}
    keys = lyte.get_pressed_keys()
    -- print(#keys)
    if #keys > 0 then
        print("count: " .. #keys)
        for i,v in ipairs(keys) do
            print(v)
        end
        print("------------------------")
    end

    lyte.draw_text("Num keys pressed in last fframe: " .. #keys, 10, 10)
end